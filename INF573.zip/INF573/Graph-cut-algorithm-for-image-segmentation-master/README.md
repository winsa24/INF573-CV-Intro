# Graph-cut-algorithm-for-image-segmentation
A C++ implementation of graph cut algorithm for image segmentation made for course INF573 at École Polytecnhique

### OpenCV
OpenCV is a library of programming functions mainly aimed at real-time computer vision.
