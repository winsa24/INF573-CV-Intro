# Non-local-patch-based-image-inpainting-algorithm
A C++ implementation of non-local patch-based image inpainting algorithm made for course INF573 at École Polytechnique

### OpenCV
OpenCV is a library of programming functions mainly aimed at real-time computer vision.
