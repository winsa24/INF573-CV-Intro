# Canny-edge-detector-algorithm
A C++ implementation of Canny edge detector algorithm made for course INF573 at École Polytechnique

### OpenCV
OpenCV is a library of programming functions mainly aimed at real-time computer vision.
