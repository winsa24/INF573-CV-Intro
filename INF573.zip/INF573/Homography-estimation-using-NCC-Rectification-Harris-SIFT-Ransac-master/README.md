# Homography-estimation-using-NCC-Rectification-Harris-SIFT-Ransac
A C++ implementation of homography estimation using NCC/Rectification/Harris/SIFT/Ransac made for course INF573 at École Polytechnique

### OpenCV
OpenCV is a library of programming functions mainly aimed at real-time computer vision.
